import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private String name;
    private String address;
    private String city;
    private static Hotel instance;
    private List<User> users;
    private List<Room> rooms;

    public Hotel() {
        this.name = "Noir Sweet";
        this.address = "Str. Andrei Muresanu, nr.10";
        this.city = "Cluj-Napoca";
        this.users = new ArrayList<>();
        this.rooms = new ArrayList<>();
    }

    public static boolean insertUser(User user) {
        String insertQuery = "INSERT INTO users (name, age, email, phone_number, password, username, user_type) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

            preparedStatement.setString(1, user.getName());
            preparedStatement.setInt(2, user.getAge());
            preparedStatement.setString(3, user.getEmail());
            preparedStatement.setString(4, user.getPhoneNumber());
            preparedStatement.setString(5, user.getPassword());
            preparedStatement.setString(6, user.getUserName());
            preparedStatement.setString(7, user.getUserType());

            int rowsInserted = preparedStatement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            System.out.println("Error: Unable to insert user into the database.");
            e.printStackTrace();
            return false;
        }
    }

    public static User getUserByUsername(String username) {
        String query = "SELECT * FROM users WHERE username = ?";
        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String email = resultSet.getString("email");
                String phone = resultSet.getString("phone_number");
                String password = resultSet.getString("password");
                String userType = resultSet.getString("user_type");

                if ("Employee".equalsIgnoreCase(userType)) {
                    return new Employee(name, age, email, phone, password, username, userType);
                } else {
                    return new User(name, age, email, phone, password, username, userType);
                }
            } else {
                return null;
            }
        } catch (SQLException e) {
            System.out.println("Error: Unable to retrieve user from the database.");
            e.printStackTrace();
            return null;
        }
    }

    public static boolean doesUsernameExist(String username) {
        String query = "SELECT COUNT(*) FROM users WHERE username = ?";
        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            resultSet.next();
            return resultSet.getInt(1) > 0;
        } catch (SQLException e) {
            System.out.println("Error: Unable to check username availability.");
            e.printStackTrace();
            return false;
        }
    }
}
