import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Customer extends User {

    public Customer(String name, int age, String email, String phoneNumber, String password, String userName, String userType, int roomNumber) {
        super(name, age, email, phoneNumber, password, userName, userType);
    }


    public static List<Room> getAvailableRooms(int nrOfPeople, Date checkInDate, Date checkOutDate) {
        List<Room> rooms = new ArrayList<>();
        String query =
                "SELECT r.* FROM rooms r " +
                        "WHERE r.capacity >= ? AND r.status = 'Available' " +
                        "AND NOT EXISTS ( " +
                        "    SELECT 1 FROM bookings b " +
                        "    WHERE b.room_id = r.id " +
                        "    AND (b.check_in_date < ? AND b.check_out_date > ?) " +
                        ")";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement roomCapacity = connection.prepareStatement(query)) {

            roomCapacity.setInt(1, nrOfPeople);
            roomCapacity.setDate(2, checkOutDate);
            roomCapacity.setDate(3, checkInDate);

            ResultSet rs = roomCapacity.executeQuery();

            while (rs.next()) {
                Room room = new Room(
                        rs.getString("status"),
                        rs.getInt("roomnumber"),
                        rs.getInt("capacity"),
                        rs.getDouble("price"),
                        rs.getString("roomtype")
                );
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rooms;
    }

    public static void changeRoomStatusToBooked(int roomNumber, Date checkInDate, Date checkOutDate) {
        LocalDate currentDate = LocalDate.now();

        if ((currentDate.isEqual(checkInDate.toLocalDate()) || currentDate.isAfter(checkInDate.toLocalDate()))
                && currentDate.isBefore(checkOutDate.toLocalDate()) || currentDate.isEqual(checkOutDate.toLocalDate())) {
            String query = "UPDATE rooms SET status = ? WHERE roomnumber = ?";
            try (Connection connection = DatabaseConnection.connectToDatabase();
                 PreparedStatement changeStatus = connection.prepareStatement(query)) {

                changeStatus.setString(1, "Booked");
                changeStatus.setInt(2, roomNumber);

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Current date is not within the check-in and check-out.");
        }
    }

    public static boolean insertCustomer(String username) {
        String getUserIdQuery = "SELECT id FROM users WHERE username = ?";
        String insertCustomerQuery = "INSERT INTO customers (id) VALUES (?)";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement getUserId = connection.prepareStatement(getUserIdQuery);
             PreparedStatement insertCustomer = connection.prepareStatement(insertCustomerQuery)) {

            getUserId.setString(1, username);
            ResultSet rs = getUserId.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("id");
                insertCustomer.setInt(1, userId);

                int rowsInserted = insertCustomer.executeUpdate();
                return rowsInserted > 0;
            } else {
                System.out.println("Username not found.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    public static boolean insertBooking(String username, int roomNumber, Date checkInDate, Date checkOutDate) {
        String getCustomerIdQuery = "SELECT id FROM customers WHERE id = (SELECT id FROM users WHERE username = ?)";
        String getRoomIdQuery = "SELECT id FROM rooms WHERE roomnumber = ?";
        String insertBookingQuery = "INSERT INTO bookings (room_id, customer_id, check_in_date, check_out_date) VALUES (?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement getCustomerId = connection.prepareStatement(getCustomerIdQuery);
             PreparedStatement getRoomId = connection.prepareStatement(getRoomIdQuery);
             PreparedStatement insertBooking = connection.prepareStatement(insertBookingQuery)) {

            getCustomerId.setString(1, username);
            ResultSet customerResult = getCustomerId.executeQuery();
            if (!customerResult.next()) {
                ///System.out.println("Customer was not found for the given username.");
                return false;
            }
            int customerId = customerResult.getInt("id");

            getRoomId.setInt(1, roomNumber);
            ResultSet roomResult = getRoomId.executeQuery();
            if (!roomResult.next()) {
                ///System.out.println("Room was not found for the given room number.");
                return false;
            }
            int roomId = roomResult.getInt("id");

            insertBooking.setInt(1, roomId);
            insertBooking.setInt(2, customerId);
            insertBooking.setDate(3, checkInDate);
            insertBooking.setDate(4, checkOutDate);

            int rowsInserted = insertBooking.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean changeRoomStatusToAvailable(String username) {
        String getRoomIdQuery = "SELECT b.room_id " +
                "FROM bookings b " +
                "JOIN customers c ON b.customer_id = c.id " +
                "JOIN users u ON c.id = u.id " +
                "WHERE u.username = ?";

        String updateRoomStatusQuery = "UPDATE rooms SET status = ? WHERE id = ?";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement getRoomId = connection.prepareStatement(getRoomIdQuery);
             PreparedStatement updateRoomStatus = connection.prepareStatement(updateRoomStatusQuery)) {

            getRoomId.setString(1, username);
            ResultSet rs = getRoomId.executeQuery();

            if (rs.next()) {
                int roomId = rs.getInt("room_id");

                updateRoomStatus.setString(1, "Available");
                updateRoomStatus.setInt(2, roomId);

                int rowsUpdated = updateRoomStatus.executeUpdate();
                return rowsUpdated > 0;
            } else {
                System.out.println("No room found for username: " + username);
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteCustomerFromDatabase(String username) {
        String getUserIdQuery = "SELECT id FROM users WHERE username = ?";
        String deleteCustomerQuery = "DELETE FROM customers WHERE id = ?";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement getUserId = connection.prepareStatement(getUserIdQuery);
             PreparedStatement deleteCustomer = connection.prepareStatement(deleteCustomerQuery)) {

            getUserId.setString(1, username);
            ResultSet rs = getUserId.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("id");
                deleteCustomer.setInt(1, userId);
                int rowsDeleted = deleteCustomer.executeUpdate();
                return rowsDeleted > 0; // Return true if rows were affected (customer deleted)
            } else {
                System.out.println("Username not found in users table.");
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static double computeAmountIfCancelBooking(String username) {
        String query = "SELECT r.price, " +
                "       (b.check_out_date - b.check_in_date) AS nights, " +
                "       b.check_in_date " +
                "FROM bookings b " +
                "JOIN rooms r ON b.room_id = r.id " +
                "JOIN customers c ON b.customer_id = c.id " +
                "JOIN users u ON c.id = u.id " +
                "WHERE u.username = ?";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement computeAmountToBePayed = connection.prepareStatement(query)) {

            computeAmountToBePayed.setString(1, username);
            ResultSet rs = computeAmountToBePayed.executeQuery();

            if (rs.next()) {
                double pricePerNight = rs.getDouble("price");
                int nights = rs.getInt("nights");
                LocalDate checkInDate = rs.getDate("check_in_date").toLocalDate();
                double totalAmount = pricePerNight * nights;
                LocalDate currentDate = LocalDate.now();

                if (currentDate.isEqual(checkInDate.minusDays(1))) {
                    return totalAmount * 0.2;
                } else {
                    System.out.println("Cancellation penalty does not apply since it's not a day before check-in.");
                }
            } else {
                System.out.println("No booking was found for username: " + username);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }



    public static boolean addReview(String username, int stars) {
        String getUserIdQuery = "SELECT id FROM users WHERE username = ?";
        String checkExistingReviewQuery = "SELECT COUNT(*) FROM ratings WHERE user_id = ?";
        String insertReviewQuery = "INSERT INTO ratings (user_id, rating_stars) VALUES (?, ?)";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement getUserId = connection.prepareStatement(getUserIdQuery);
             PreparedStatement checkExistingReview = connection.prepareStatement(checkExistingReviewQuery);
             PreparedStatement insertReview = connection.prepareStatement(insertReviewQuery)) {

            getUserId.setString(1, username);
            ResultSet rs = getUserId.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("id");
                checkExistingReview.setInt(1, userId);
                ResultSet reviewCheckResult = checkExistingReview.executeQuery();

                if (reviewCheckResult.next() && reviewCheckResult.getInt(1) > 0) {
                    ///System.out.println("User has already left a review.");
                    return false;
                }

                insertReview.setInt(1, userId);
                insertReview.setInt(2, stars);

                int rowsInserted = insertReview.executeUpdate();
                return rowsInserted > 0;
            } else {
                System.out.println("Username not found.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean deleteFromBookings(String username) {
        String getCustomerIdQuery = "SELECT c.id " +
                "FROM customers c " +
                "JOIN users u ON c.id = u.id " +
                "WHERE u.username = ?";

        String deleteBookingsQuery = "DELETE FROM bookings WHERE customer_id = ?";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement getCustomerId = connection.prepareStatement(getCustomerIdQuery);
             PreparedStatement deleteBookings = connection.prepareStatement(deleteBookingsQuery)) {

            getCustomerId.setString(1, username);
            ResultSet rs = getCustomerId.executeQuery();

            if (rs.next()) {
                int customerId = rs.getInt("id");

                deleteBookings.setInt(1, customerId);

                int rowsDeleted = deleteBookings.executeUpdate();
                return rowsDeleted > 0;
            } else {
                System.out.println("No customer found for username: " + username);
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Date getTheCheckInDate(String username) {
        String query = "SELECT b.check_in_date " +
                "FROM bookings b " +
                "JOIN customers c ON b.customer_id = c.id " +
                "JOIN users u ON c.id = u.id " +
                "WHERE u.username = ?";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement getDate = connection.prepareStatement(query)) {

            getDate.setString(1, username);
            ResultSet rs = getDate.executeQuery();

            if (rs.next()) {
                return rs.getDate("check_in_date");
            } else {
                System.out.println("No bookings found for username: " + username);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static boolean bookActivity(String username, String activityName) {
        String findBookingQuery = "SELECT b.id AS booking_id " +
                "FROM bookings b " +
                "JOIN customers c ON b.customer_id = c.id " +
                "JOIN users u ON c.id = u.id " +
                "WHERE u.username = ?";

        String findActivityQuery = "SELECT id AS activity_id " +
                "FROM activities " +
                "WHERE activity_name = ?";

        String insertBookActivityQuery = "INSERT INTO book_activities (activity_id, booking_id) VALUES (?, ?)";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement findBooking = connection.prepareStatement(findBookingQuery);
             PreparedStatement findActivity = connection.prepareStatement(findActivityQuery);
             PreparedStatement insertBookActivity = connection.prepareStatement(insertBookActivityQuery)) {

            findBooking.setString(1, username);
            ResultSet bookingResult = findBooking.executeQuery();

            if (!bookingResult.next()) {
                System.out.println("No active booking found for username: " + username);
                return false;
            }
            int bookingId = bookingResult.getInt("booking_id");

            findActivity.setString(1, activityName);
            ResultSet activityResult = findActivity.executeQuery();

            if (!activityResult.next()) {
                System.out.println("Activity not found: " + activityName);
                return false;
            }
            int activityId = activityResult.getInt("activity_id");

            insertBookActivity.setInt(1, activityId);
            insertBookActivity.setInt(2, bookingId);

            int rowsInserted = insertBookActivity.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Activity booked successfully for username: " + username);
                return true;
            } else {
                System.out.println("Failed to book the activity for username: " + username);
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean doesCustomerExist(String username) {
        String query = "SELECT c.id FROM customers c JOIN users u ON c.id = u.id WHERE u.username = ?";
        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement findCustomer = connection.prepareStatement(query)) {

            findCustomer.setString(1, username);
            ResultSet resultSet = findCustomer.executeQuery();

            return resultSet.next();

        } catch (SQLException e) {
            System.err.println("Error: Unable to check if customer exists for username: " + username);
            e.printStackTrace();
            return false;
        }
    }

    public static boolean doesBookingExist(String username) {
        String query = "SELECT 1 " +
                "FROM bookings b " +
                "JOIN customers c ON b.customer_id = c.id " +
                "JOIN users u ON c.id = u.id " +
                "WHERE u.username = ?";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement findBooking = connection.prepareStatement(query)) {

            findBooking.setString(1, username);
            ResultSet rs = findBooking.executeQuery();

            return rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


}
