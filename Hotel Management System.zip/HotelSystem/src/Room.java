public class Room {
    private String status;
    private int roomNumber;
    private int capacity;
    private double price;
    private String roomType;

    public Room(String status, int roomNumber, int capacity, double price, String roomType) {
        this.status = status;
        this.roomNumber = roomNumber;
        this.capacity = capacity;
        this.price = price;
        this.roomType = roomType;
    }

    public String getStatus() {
        return status;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public double getPrice() {
        return price;
    }
    public String getRoomType() {
        return roomType;
    }


}
