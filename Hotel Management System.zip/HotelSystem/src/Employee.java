import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class Employee extends User {

    public Employee(String name, int age, String email, String phoneNumber, String password, String userName, String userType) {
        super(name, age, email, phoneNumber, password, userName, userType);
    }

    public boolean addRoom(Room room) {
        String query = "INSERT INTO rooms (roomNumber, status, capacity, price, roomType) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement addRoom = connection.prepareStatement(query)) {

            addRoom.setInt(1, room.getRoomNumber());
            addRoom.setString(2, room.getStatus());
            addRoom.setInt(3, room.getCapacity());
            addRoom.setDouble(4, room.getPrice());
            addRoom.setString(5, room.getRoomType());

            int count = addRoom.executeUpdate();
            return count > 0;
        } catch (SQLException e) {
            System.out.println("Error: Unable to add room to the database.");
            e.printStackTrace();
            return false;
        }
    }

    public static boolean changeRoomStatusToAvailable(int roomNumber) {
        String query = "UPDATE rooms SET status = ? WHERE roomnumber = ?";
        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement changeStatus = connection.prepareStatement(query)) {

            changeStatus.setString(1, "Available");
            changeStatus.setInt(2, roomNumber);

            int count = changeStatus.executeUpdate();
            return count > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


public static double computeTotalAmount(int roomNumber) {
    String roomBookingQuery = "SELECT r.price AS room_price, " +
            "       (b.check_out_date - b.check_in_date) AS nights, " +
            "       b.id AS booking_id " +
            "FROM rooms r " +
            "JOIN bookings b ON r.id = b.room_id " +
            "WHERE r.roomNumber = ?";

    String activitiesQuery = "SELECT a.price AS activity_price " +
            "FROM book_activities ba " +
            "JOIN activities a ON ba.activity_id = a.id " +
            "WHERE ba.booking_id = ?";

    try (Connection connection = DatabaseConnection.connectToDatabase();
         PreparedStatement roomBooking = connection.prepareStatement(roomBookingQuery);
         PreparedStatement activities = connection.prepareStatement(activitiesQuery)) {


        roomBooking.setInt(1, roomNumber);
        ResultSet roomResult = roomBooking.executeQuery();

        if (!roomResult.next()) {
            ///System.out.println("No booking found for room number: " + roomNumber);
            return 0;
        }

        double roomPricePerNight = roomResult.getDouble("room_price");
        int nights = roomResult.getInt("nights");
        int bookingId = roomResult.getInt("booking_id");
        double roomTotal = roomPricePerNight * nights;

        activities.setInt(1, bookingId);
        ResultSet activitiesResult = activities.executeQuery();

        double activitiesTotal = 0.0;
        while (activitiesResult.next()) {
            activitiesTotal += activitiesResult.getDouble("activity_price");
        }

        return roomTotal + activitiesTotal;

    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
}

    public static boolean addFacility(String facilityName, double price) {
        String query = "INSERT INTO facilities (facility_name, price) VALUES (?, ?)";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, facilityName);
            statement.setDouble(2, price);

            int count = statement.executeUpdate();
            return count > 0;
        } catch (SQLException e) {
            ///System.out.println("Error: Unable to add facility to the database.");
            e.printStackTrace();
            return false;
        }
    }


    public static boolean deleteFromActivitiesAndBookings(int room_number) {
        String getBookingIdQuery = "SELECT b.id AS booking_id " +
                "FROM bookings b " +
                "JOIN rooms r ON b.room_id = r.id " +
                "WHERE r.roomNumber = ?";

        String deleteActivitiesQuery = "DELETE FROM book_activities WHERE booking_id = ?";
        String deleteBookingsQuery = "DELETE FROM bookings WHERE id = ?";

        try (Connection connection = DatabaseConnection.connectToDatabase();
             PreparedStatement getBookingId = connection.prepareStatement(getBookingIdQuery);
             PreparedStatement deleteActivities = connection.prepareStatement(deleteActivitiesQuery);
             PreparedStatement deleteBookings = connection.prepareStatement(deleteBookingsQuery)) {

            getBookingId.setInt(1, room_number);
            ResultSet rs = getBookingId.executeQuery();

            if (rs.next()) {
                int bookingId = rs.getInt("booking_id");

                deleteActivities.setInt(1, bookingId);
                deleteActivities.executeUpdate();
                deleteBookings.setInt(1, bookingId);

                int count = deleteBookings.executeUpdate();
                return count > 0;
            } else {
                ///System.out.println("No booking found for room number: " + room_number);
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


}
