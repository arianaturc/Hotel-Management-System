import javax.swing.*;
import javax.swing.plaf.basic.BasicComboBoxUI;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class UserView {
    private JFrame frame;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private JTextField logInUsernameField;
    private JPasswordField logInPasswordField;
    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JLabel hotelTitleLabel;
    private JTextField signUpNameField;
    private JTextField signUpAgeField;
    private JTextField signUpEmailField;
    private JTextField signUpPhoneField;
    private JTextField signUpUsernameField;
    private JPasswordField signUpPasswordField;
    private JComboBox<String> userTypeComboBox;
    private JButton logInButton;
    private JButton switchToSignInButton;
    private JButton signUpButton;
    private JButton switchToLogInButton;
    private JButton addRoomButton;
    private JButton saveRoomButton;
    private JButton bookRoomButton;
    private JButton findRoomButton;
    private JButton bookButton;
    private JButton cancelBookingButton;
    private JButton checkOutCustomerButton;
    private JButton checkOutButton;
    private JButton bookActivityButton;
    private JButton addFacilityButton;
    private JButton saveFacilityButton;
    private JButton activityBookingButton;
    private JButton reviewButton;
    private JButton saveReviewButton;
    private JButton backButton1;
    private JButton backButton2;
    private JButton backButton3;
    private JButton backButton6;
    private JComboBox<String> addRoomStatusField;
    private JTextField addRoomNumberField;
    private JTextField addRoomCapacityField;
    private JTextField addRoomPriceField;
    private JTextField addNumberOfPeopleField;
    private JTextField checkInDateField;
    private JTextField checkOutDateField;
    private JTextField roomNumberField;
    private JTextField facilityNameField;
    private JTextField priceFacilityField;
    private JComboBox<String> addRoomTypeField;
    private JComboBox<String> roomField;
    private JComboBox<String> activityName;
    private JComboBox<String> reviewStars;


    public UserView() {
        initializeUI();
    }

    private void initializeUI() {
        frame = new JFrame("Hotel Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createLogInPanel(), "LogIn");
        mainPanel.add(createSignUpPanel(), "SignIn");

        frame.add(mainPanel);
        cardLayout.show(mainPanel, "LogIn");

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);


    }

    private JPanel createLogInPanel() {
        JPanel logInPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        logInPanel.setBackground(new Color(224, 220, 211));

        hotelTitleLabel = new JLabel("Hotel Black Sweet");
        hotelTitleLabel.setFont(new Font("Serif", Font.BOLD, 35));
        hotelTitleLabel.setForeground(new Color(92, 64, 52));

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTH;
        logInPanel.add(hotelTitleLabel, gbc);


        usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        usernameLabel.setForeground(Color.BLACK);
        logInUsernameField = new JTextField(15);

        gbc.gridx = 0;
        gbc.gridy = 1;
        logInPanel.add(usernameLabel, gbc);

        gbc.gridx = 1;
        logInPanel.add(logInUsernameField, gbc);

        passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        passwordLabel.setForeground(Color.BLACK);
        logInPasswordField = new JPasswordField(15);

        gbc.gridx = 0;
        gbc.gridy = 2;
        logInPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        logInPanel.add(logInPasswordField, gbc);

        logInButton = new JButton("Log In");
        logInButton.setBackground(new Color(150, 121, 105));
        logInButton.setForeground(Color.WHITE);

        switchToSignInButton = new JButton("Sign Up");
        switchToSignInButton.setBackground(new Color(150, 121, 105));
        switchToSignInButton.setForeground(Color.WHITE);

        gbc.gridx = 0;
        gbc.gridy = 3;
        logInPanel.add(logInButton, gbc);

        gbc.gridx = 1;
        logInPanel.add(switchToSignInButton, gbc);


        addRoomButton = new JButton("Add Room");
        addRoomButton.setBackground(new Color(92, 64, 52));
        addRoomButton.setForeground(Color.WHITE);
        addRoomButton.setVisible(false);

        gbc.gridx = 0;
        gbc.gridy = 3;
        logInPanel.add(addRoomButton, gbc);

        checkOutCustomerButton = new JButton("Check-out");
        checkOutCustomerButton.setBackground(new Color(66, 28, 28));
        checkOutCustomerButton.setForeground(Color.WHITE);
        checkOutCustomerButton.setVisible(false);

        gbc.gridx = 1;
        gbc.gridy = 5;
        logInPanel.add(checkOutCustomerButton, gbc);


        addFacilityButton = new JButton("Add Facility");
        addFacilityButton.setBackground(new Color(92, 64, 52));
        addFacilityButton.setForeground(Color.WHITE);
        addFacilityButton.setVisible(false);
        gbc.gridx = 2;
        gbc.gridy = 3;
        logInPanel.add(addFacilityButton, gbc);


        saveRoomButton = new JButton("Save Room");
        saveRoomButton.setBackground(new Color(92, 64, 52));
        saveRoomButton.setForeground(Color.WHITE);
        saveRoomButton.setVisible(false);


        findRoomButton = new JButton("Find Room");
        findRoomButton.setBackground(new Color(92, 64, 52));
        findRoomButton.setForeground(Color.WHITE);
        findRoomButton.setVisible(false);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.WEST;
        bookRoomButton = new JButton("Book Room");
        bookRoomButton.setBackground(new Color(92, 64, 52));
        bookRoomButton.setForeground(Color.WHITE);
        bookRoomButton.setVisible(false);
        logInPanel.add(bookRoomButton, gbc);


        bookButton = new JButton("Book Room");
        bookButton.setBackground(new Color(92, 64, 52));
        bookButton.setForeground(Color.WHITE);


        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.WEST;
        cancelBookingButton = new JButton("Cancel Booking");
        cancelBookingButton.setBackground(new Color(92, 64, 52));
        cancelBookingButton.setForeground(Color.WHITE);
        cancelBookingButton.setVisible(false);
        logInPanel.add(cancelBookingButton, gbc);


        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.WEST;
        bookActivityButton = new JButton("Book activity");
        bookActivityButton.setBackground(new Color(92, 64, 52));
        bookActivityButton.setForeground(Color.WHITE);
        bookActivityButton.setVisible(false);
        logInPanel.add(bookActivityButton, gbc);


        gbc.gridx = 2;
        gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.WEST;
        reviewButton = new JButton("Add Review");
        reviewButton.setBackground(new Color(66, 28, 28));
        reviewButton.setForeground(Color.WHITE);
        reviewButton.setVisible(false);
        logInPanel.add(reviewButton, gbc);


        saveReviewButton = new JButton("Save Review");
        saveReviewButton.setBackground(new Color(66, 28, 28));
        saveReviewButton.setForeground(Color.WHITE);
        saveReviewButton.setVisible(false);
        logInPanel.add(saveReviewButton, gbc);


        checkOutButton = new JButton("Check-out Room");
        checkOutButton.setBackground(new Color(92, 64, 52));
        checkOutButton.setForeground(Color.WHITE);
        checkOutButton.setVisible(false);

        saveFacilityButton = new JButton("Save Facility");
        saveFacilityButton.setBackground(new Color(92, 64, 52));
        saveFacilityButton.setForeground(Color.WHITE);
        saveFacilityButton.setVisible(false);

        activityBookingButton = new JButton("Book");
        activityBookingButton.setBackground(new Color(51, 36, 33));
        activityBookingButton.setForeground(Color.WHITE);
        activityBookingButton.setVisible(false);

        backButton1 = new JButton("Back");
        backButton1.setBackground(new Color(92, 64, 52));
        backButton1.setForeground(Color.WHITE);
        backButton1.setVisible(false);

        backButton2 = new JButton("Back");
        backButton2.setBackground(new Color(92, 64, 52));
        backButton2.setForeground(Color.WHITE);
        backButton2.setVisible(false);

        backButton3 = new JButton("Back");
        backButton3.setBackground(new Color(92, 64, 52));
        backButton3.setForeground(Color.WHITE);
        backButton3.setVisible(false);


        gbc.gridx = 1;
        gbc.gridy = 8;
        backButton6 = new JButton("Back To Login");
        backButton6.setBackground(new Color(150, 121, 105));
        backButton6.setForeground(Color.WHITE);
        backButton6.setVisible(false);
        logInPanel.add(backButton6, gbc);


        return logInPanel;
    }

    private JPanel createSignUpPanel() {
        JPanel signInPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        signInPanel.setBackground(new Color(224, 220, 211));

        signUpNameField = createTextFieldWithLabel(signInPanel, "Full Name:", 0, gbc);
        signUpAgeField = createTextFieldWithLabel(signInPanel, "Age:", 1, gbc);
        signUpEmailField = createTextFieldWithLabel(signInPanel, "Email:", 2, gbc);
        signUpPhoneField = createTextFieldWithLabel(signInPanel, "Phone Number:", 3, gbc);
        signUpUsernameField = createTextFieldWithLabel(signInPanel, "Username:", 4, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        signUpPasswordField = new JPasswordField(15);
        gbc.gridx = 0;
        gbc.gridy = 5;
        signInPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        signInPanel.add(signUpPasswordField, gbc);

        JLabel userTypeLabel = new JLabel("User Type:");
        userTypeComboBox = new JComboBox<>(new String[]{"Customer", "Employee"});
        userTypeComboBox.setFont(new Font("Arial", Font.BOLD, 14));

        userTypeComboBox.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton arrowButton = super.createArrowButton();
                arrowButton.setBackground(new Color(150, 121, 105));
                arrowButton.setForeground(Color.WHITE);
                return arrowButton;
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 6;
        signInPanel.add(userTypeLabel, gbc);
        gbc.gridx = 1;
        signInPanel.add(userTypeComboBox, gbc);

        signUpButton = new JButton("Sign Up");
        signUpButton.setBackground(new Color(150, 121, 105));
        signUpButton.setForeground(Color.WHITE);

        switchToLogInButton = new JButton("Log In");
        switchToLogInButton.setBackground(new Color(150, 121, 105));
        switchToLogInButton.setForeground(Color.WHITE);

        gbc.gridx = 0;
        gbc.gridy = 7;
        signInPanel.add(signUpButton, gbc);
        gbc.gridx = 1;
        signInPanel.add(switchToLogInButton, gbc);

        return signInPanel;
    }

    private JTextField createTextFieldWithLabel(JPanel panel, String labelText, int row, GridBagConstraints gbc) {
        JLabel label = new JLabel(labelText);
        JTextField textField = new JTextField(15);

        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(label, gbc);

        gbc.gridx = 1;
        panel.add(textField, gbc);

        return textField;
    }


    public void showAddRoomButton() {
        logInUsernameField.setVisible(false);
        logInPasswordField.setVisible(false);
        usernameLabel.setVisible(false);
        passwordLabel.setVisible(false);
        logInButton.setVisible(false);
        switchToSignInButton.setVisible(false);
        addRoomButton.setVisible(true);
        addRoomButton.setFocusPainted(false);
        checkOutCustomerButton.setVisible(true);
        addFacilityButton.setVisible(true);
        hotelTitleLabel.setVisible(false);
        //backButton6.setVisible(true);
    }


    public void showAddRoomForm() {
        JPanel addRoomPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        addRoomPanel.setBackground(new Color(224, 220, 211));

        addRoomNumberField = createTextFieldWithLabel(addRoomPanel, "Room Number:", 0, gbc);
        addRoomCapacityField = createTextFieldWithLabel(addRoomPanel, "Capacity:", 1, gbc);
        addRoomPriceField = createTextFieldWithLabel(addRoomPanel, "Price:", 2, gbc);


        JLabel statusLabel = new JLabel("Room Status:");
        addRoomStatusField = new JComboBox<>(new String[]{"Booked", "Available"});
        gbc.gridx = 0;
        gbc.gridy = 3;
        addRoomPanel.add(statusLabel, gbc);
        gbc.gridx = 1;
        addRoomPanel.add(addRoomStatusField, gbc);

        addRoomStatusField.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton arrowButton = super.createArrowButton();
                arrowButton.setBackground(new Color(150, 121, 105));
                arrowButton.setForeground(Color.WHITE);
                return arrowButton;
            }
        });


        JLabel typeLabel = new JLabel("Room Type:");
        addRoomTypeField = new JComboBox<>(new String[]{"Single", "Double", "Triple", "Apartment", "Suite"});
        gbc.gridx = 0;
        gbc.gridy = 4;
        addRoomPanel.add(typeLabel, gbc);
        gbc.gridx = 1;
        addRoomPanel.add(addRoomTypeField, gbc);

        addRoomTypeField.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton arrowButton = super.createArrowButton();
                arrowButton.setBackground(new Color(150, 121, 105));
                arrowButton.setForeground(Color.WHITE);
                return arrowButton;
            }
        });

        saveRoomButton.setVisible(true);
        backButton3.setVisible(true);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        addRoomPanel.add(saveRoomButton, gbc);

        gbc.gridx = 2;
        gbc.gridy = 6;
        addRoomPanel.add(backButton3, gbc);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(addRoomPanel);
        frame.revalidate();
        frame.repaint();
    }

    public void showBookRoomButton() {
        logInUsernameField.setVisible(false);
        logInPasswordField.setVisible(false);
        usernameLabel.setVisible(false);
        passwordLabel.setVisible(false);
        logInButton.setVisible(false);
        switchToSignInButton.setVisible(false);
        addRoomButton.setVisible(false);
        bookRoomButton.setVisible(true);
        bookRoomButton.setFocusPainted(false);
        bookActivityButton.setVisible(true);
        reviewButton.setVisible(true);
        cancelBookingButton.setVisible(true);
        hotelTitleLabel.setVisible(false);
        //backButton6.setVisible(true);
    }

    public void showFindRoomButton() {
        logInUsernameField.setVisible(false);
        logInPasswordField.setVisible(false);
        usernameLabel.setVisible(false);
        passwordLabel.setVisible(false);
        logInButton.setVisible(false);
        switchToSignInButton.setVisible(false);
        addRoomButton.setVisible(false);
        bookRoomButton.setVisible(false);
        findRoomButton.setVisible(true);
    }

    public void showBookRoomForm() {
        JPanel bookRoomPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        bookRoomPanel.setBackground(new Color(224, 220, 211));


        addNumberOfPeopleField = createTextFieldWithLabel(bookRoomPanel, "Number of people:", 0, gbc);
        checkInDateField = createTextFieldWithLabel(bookRoomPanel, "Check-in date:", 1, gbc);
        checkOutDateField = createTextFieldWithLabel(bookRoomPanel, "Check-out date:", 2, gbc);

        findRoomButton.setVisible(true);
        backButton1.setVisible(true);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        bookRoomPanel.add(findRoomButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        bookRoomPanel.add(backButton1, gbc);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(bookRoomPanel);
        frame.revalidate();
        frame.repaint();
    }

    public void showAvailableRooms(List<Room> availableRooms) {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(224, 220, 211));

        JPanel roomsPanel = new JPanel();
        roomsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.NORTHWEST;

        if (availableRooms.isEmpty()) {
            JLabel noRoomsLabel = new JLabel("No available rooms found.");
            gbc.gridy = 0;
            roomsPanel.add(noRoomsLabel, gbc);
        } else {
            int row = 0;
            for (Room room : availableRooms) {
                JPanel roomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0)); // Tight layout for room details


                roomPanel.add(new JLabel("Room Number: " + room.getRoomNumber()));
                roomPanel.add(new JLabel("Capacity: " + room.getCapacity() + " people"));
                roomPanel.add(new JLabel("Price: $" + room.getPrice()));

                gbc.gridy = row++;
                roomsPanel.add(roomPanel, gbc);
            }
        }


        JScrollPane scrollPane = new JScrollPane(roomsPanel);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        mainPanel.add(scrollPane, BorderLayout.NORTH);
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        GridBagConstraints gbcRooms = new GridBagConstraints();
        gbcRooms.insets = new Insets(10, 10, 10, 10);
        roomField = new JComboBox<>();

        roomField.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton arrowButton = super.createArrowButton();
                arrowButton.setBackground(new Color(150, 121, 105));
                arrowButton.setForeground(Color.WHITE);
                return arrowButton;
            }
        });

        for (Room room : availableRooms) {
            String roomNumber = Integer.toString(room.getRoomNumber());
            roomField.addItem(roomNumber);
        }

        gbcRooms.gridx = 0;
        gbcRooms.gridy = 3;
        actionPanel.add(new JLabel("Select a Room:"), gbcRooms);

        gbcRooms.gridx = 1;
        actionPanel.add(roomField, gbcRooms);
        actionPanel.add(bookButton, gbcRooms);

        mainPanel.add(actionPanel, BorderLayout.CENTER);
        backButton1.setVisible(true);
        actionPanel.add(backButton1, gbcRooms);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(mainPanel);
        frame.revalidate();
        frame.repaint();
    }

    public void showReviewPanel() {
        JPanel reviewPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        reviewPanel.setBackground(new Color(224, 220, 211));

        JLabel typeLabel = new JLabel("Stars:");
        reviewStars = new JComboBox<>(new String[]{"1", "2", "3", "4", "5"});

        reviewStars.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton arrowButton = super.createArrowButton();
                arrowButton.setBackground(new Color(66, 28, 28));
                arrowButton.setForeground(Color.WHITE);
                return arrowButton;
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        reviewPanel.add(typeLabel, gbc);

        gbc.gridx = 1;
        reviewPanel.add(reviewStars, gbc);

        backButton1.setVisible(true);
        saveReviewButton.setVisible(true);

        gbc.gridx = 1;
        gbc.gridy = 1;
        reviewPanel.add(saveReviewButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        reviewPanel.add(backButton1, gbc);


        frame.getContentPane().removeAll();
        frame.getContentPane().add(reviewPanel);
        frame.revalidate();
        frame.repaint();

    }

    public void showCheckOutForm() {
        JPanel checkOutPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        checkOutPanel.setBackground(new Color(224, 220, 211));

        checkOutButton.setVisible(true);

        roomNumberField = createTextFieldWithLabel(checkOutPanel, "Room number: ", 0, gbc);
        backButton3.setVisible(true);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        checkOutPanel.add(checkOutButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        checkOutPanel.add(backButton3, gbc);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(checkOutPanel);
        frame.revalidate();
        frame.repaint();
    }



    public void showAddFacilityForm() {
        JPanel addFacilityPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        addFacilityPanel.setBackground(new Color(224, 220, 211));


        saveFacilityButton.setVisible(true);

        facilityNameField = createTextFieldWithLabel(addFacilityPanel, "Facility name:", 0, gbc);
        priceFacilityField = createTextFieldWithLabel(addFacilityPanel, "Price:", 1, gbc);

        backButton3.setVisible(true);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        addFacilityPanel.add(saveFacilityButton, gbc);

        gbc.gridx = 2;
        gbc.gridy = 3;
        addFacilityPanel.add(backButton3, gbc);


        frame.getContentPane().removeAll();
        frame.getContentPane().add(addFacilityPanel);
        frame.revalidate();
        frame.repaint();
    }

    public void customerPanel() {
        JPanel customerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        customerPanel.setBackground(new Color(224, 220, 211));

        bookRoomButton.setVisible(true);
        cancelBookingButton.setVisible(true);
        reviewButton.setVisible(true);
        bookActivityButton.setVisible(true);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        customerPanel.add(bookRoomButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        customerPanel.add(cancelBookingButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        customerPanel.add(bookActivityButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        customerPanel.add(reviewButton, gbc);


        gbc.gridx = 1;
        gbc.gridy = 2;
        //backButton6.setVisible(true);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(customerPanel);
        frame.revalidate();
        frame.repaint();

    }

    public void employeePanel() {
        JPanel employeePanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        employeePanel.setBackground(new Color(224, 220, 211));

        addRoomButton.setVisible(true);
        addFacilityButton.setVisible(true);
        checkOutCustomerButton.setVisible(true);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        employeePanel.add(addRoomButton, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        employeePanel.add(addFacilityButton, gbc);


        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        employeePanel.add(checkOutCustomerButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        //backButton6.setVisible(true);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(employeePanel);
        frame.revalidate();
        frame.repaint();

    }



    public void showChooseActivityForm() {
        JPanel chooseFacility = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        chooseFacility.setBackground(new Color(224, 220, 211));


        JLabel typeLabel = new JLabel("Facilities:");
        activityName = new JComboBox<>(new String[]{"Breakfast", "Spa & Massage", "Tennis Court", "Swimming Pool"});
        gbc.gridx = 0;
        gbc.gridy = 4;
        chooseFacility.add(typeLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        chooseFacility.add(activityName, gbc);
        activityName.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton arrowButton = super.createArrowButton();
                arrowButton.setBackground(new Color(150, 121, 105));
                arrowButton.setForeground(Color.WHITE);
                return arrowButton;
            }
        });


        activityBookingButton.setVisible(true);
        gbc.gridx = 0;
        gbc.gridy = 5;
        chooseFacility.add(activityBookingButton, gbc);

        backButton1.setVisible(true);
        gbc.gridx = 1;
        gbc.gridy = 6;
        chooseFacility.add(backButton1, gbc);


        frame.getContentPane().removeAll();
        frame.getContentPane().add(chooseFacility);
        frame.revalidate();
        frame.repaint();
    }





    public String getLogInUsername() {
        return logInUsernameField.getText();
    }

    public String getLogInPassword() {
        return new String(logInPasswordField.getPassword());
    }

    public String getSignUpName() {
        return signUpNameField.getText();
    }

    public String getSignUpAge() {
        return signUpAgeField.getText();
    }

    public String getSignUpEmail() {
        return signUpEmailField.getText();
    }

    public String getSignUpPhone() {
        return signUpPhoneField.getText();
    }

    public String getSignUpUsername() {
        return signUpUsernameField.getText();
    }

    public String getSignUpPassword() {
        return new String(signUpPasswordField.getPassword());
    }

    public String getUserType() {
        return (String) userTypeComboBox.getSelectedItem();
    }

    public void showLogInScreen() {
        cardLayout.show(mainPanel, "LogIn");
    }

    public void showSignUpScreen() {
        cardLayout.show(mainPanel, "SignIn");
    }

    public void addLogInListener(ActionListener listener) {
        logInButton.addActionListener(listener);
    }

    public void addSwitchToSignInListener(ActionListener listener) {
        switchToSignInButton.addActionListener(listener);
    }

    public void addSignUpListener(ActionListener listener) {
        signUpButton.addActionListener(listener);
    }

    public void addSwitchToLogInListener(ActionListener listener) {
        switchToLogInButton.addActionListener(listener);
    }

    public void addAddRoomListener(ActionListener listener) {
        addRoomButton.addActionListener(listener);
    }

    public void showMessage(String message, String title, int messageType) {
        JOptionPane.showMessageDialog(frame, message, title, messageType);
    }


    public void addCheckOutCustomerButton(ActionListener listener) {
        checkOutCustomerButton.addActionListener(listener);
    }

    public void addBookActivityButton(ActionListener listener) {
        bookActivityButton.addActionListener(listener);
    }

    public void addActivityBookingButton(ActionListener listener) {
        activityBookingButton.addActionListener(listener);
    }

    public String getNameFacility() {
        return activityName.getSelectedItem().toString();
    }

    public String getReviewStars() {
        return reviewStars.getSelectedItem().toString();
    }

    public void addBookRoom(ActionListener listener){
        bookButton.addActionListener(listener);
    }

    public void addFacilityButton(ActionListener listener) {
        addFacilityButton.addActionListener(listener);
    }

    public void addSaveFacilityButton(ActionListener listener) {
        saveFacilityButton.addActionListener(listener);
    }

    public void addCancelBookingButton(ActionListener listener) {
        cancelBookingButton.addActionListener(listener);
    }

    public void addCheckOutButton(ActionListener listener) {
        checkOutButton.addActionListener(listener);
    }

    public String getFacilityName() {
        return facilityNameField.getText();
    }

    public String getFacilityPrice() {
        return priceFacilityField.getText();
    }

    public String getRoomNumberForCheckOut() {
        return roomNumberField.getText();
    }

    public int getNumberAvailableRoom() {
        return Integer.parseInt(roomField.getSelectedItem().toString());
    }

    public void addBookRoomButton(ActionListener listener) {
        bookRoomButton.addActionListener(listener);
    }

    public void addSaveRoomListener(ActionListener listener){
        saveRoomButton.addActionListener(listener);
    }

    public void addFindRoomButton(ActionListener listener) {
        findRoomButton.addActionListener(listener);
    }

    public String getRoomNumber() {
        return addRoomNumberField.getText();
    }

    public String getRoomStatus() {
        return (String) addRoomStatusField.getSelectedItem();
    }

    public String getRoomCapacity() {
        return addRoomCapacityField.getText();
    }

    public String getRoomPrice() {
        return addRoomPriceField.getText();
    }

    public String getRoomType() {
        return (String) addRoomTypeField.getSelectedItem();
    }

    public String getNrOfPeople() {
        return addNumberOfPeopleField.getText();
    }

    public String getCheckInDate() {
        return checkInDateField.getText();
    }

    public String getCheckOutDate(){
        return checkOutDateField.getText();
    }

    public void addBackButton1(ActionListener listener) {
        backButton1.addActionListener(listener);
    }


    public void addBackButton3(ActionListener listener) {
        backButton3.addActionListener(listener);
    }


    public void addBackButton6(ActionListener listener) {
        backButton6.addActionListener(listener);
    }

    public void addReviewButton(ActionListener listener) {
        reviewButton.addActionListener(listener);
    }

    public void addSaveReviewButton(ActionListener listener) {
        saveReviewButton.addActionListener(listener);
    }


}
