import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;


public class DatabaseConnection {

    private static final String URL = "jdbc:postgresql://localhost:5432/hotelsystem";
    private static final String USER = "postgres";
    private static final String PASSWORD = "Databases2019";


    public static Connection connectToDatabase() {
        try {
            Class.forName("org.postgresql.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Error: Unable to connect to the database.");
            return null;
        }
    }


}
