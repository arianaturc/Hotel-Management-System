import java.util.Scanner;

public class User {
    private final String name;
    private final int age;
    private final String email;
    private final String phoneNumber;
    private final  String password;
    private final String userName;
    private final String userType;

    public User(String name, int age, String email, String phoneNumber, String password, String userName, String userType) {
        this.name = name;
        this.age = age;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.userName = userName;
        this.userType = userType;

    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword(){
        return password;
    }

    public String getUserName(){
        return userName;
    }
    public String getUserType(){
        return userType;
    }

}
