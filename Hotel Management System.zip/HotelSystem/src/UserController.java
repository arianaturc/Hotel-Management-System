import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.sql.Date;
import java.util.List;


public class UserController {
    private final UserView view;

    public UserController(UserView view) {
        this.view = view;
        addListeners();
    }

    private void addListeners() {
        view.addLogInListener(e -> handleLogIn());
        view.addSwitchToSignInListener(e -> view.showSignUpScreen());
        view.addSignUpListener(e -> handleSignUp());
        view.addSwitchToLogInListener(e -> view.showLogInScreen());
        view.addBookRoomButton(e -> handleBookRoom());
        view.addFindRoomButton(e -> handleFindRoom());
        view.addCancelBookingButton(e -> handleCancelBookingButton());
        view.addBookRoom(e -> handleBookRoomButton());
        view.addReviewButton(e -> handleReviewButton());
        view.addSaveReviewButton(e -> handleSaveReviewButton());
        view.addAddRoomListener(e -> handleAddRoom());
        view.addSaveRoomListener(e -> handleSaveRoom());
        view.addCheckOutCustomerButton(e -> handleCheckOutCustomerButton());
        view.addCheckOutButton(e -> handleCheckOutButton());
        view.addFacilityButton(e -> handleAddFacilityButton());
        view.addSaveFacilityButton(e -> handleSaveFacilityButton());
        view.addBookActivityButton(e ->handleBookActivityButton());
        view.addActivityBookingButton(e -> handleActivityBookingButton());

        view.addBackButton1(e -> handleBackButton1());
        view.addBackButton3(e -> handleBackButton3());
    }



    private void handleLogIn() {
        String username = view.getLogInUsername();
        String password = view.getLogInPassword();

        if(username.isEmpty() || password.isEmpty()) {
            view.showMessage("All fields must be filled out.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        User user = Hotel.getUserByUsername(username);

        if (user != null && user.getPassword().equals(password)) {
            view.showMessage("Log-in successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            if(user.getUserType().equals("Employee")) {
                view.showAddRoomButton();
            } else {
                view.showBookRoomButton();
            }

        } else {
            view.showMessage("Invalid username or password. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void handleSignUp() {
        String name = view.getSignUpName();
        String ageText = view.getSignUpAge();
        String email = view.getSignUpEmail();
        String phone = view.getSignUpPhone();
        String username = view.getSignUpUsername();
        String password = view.getSignUpPassword();
        String userType = view.getUserType();

        if (name.isEmpty() || ageText.isEmpty() || email.isEmpty() || phone.isEmpty() || username.isEmpty() || password.isEmpty()) {
            view.showMessage("All fields must be filled out.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int age = Integer.parseInt(ageText);
            if (age < 18) {
                view.showMessage("You must be at least 18 years old.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!phone.matches("\\d{10}")) {
                view.showMessage("Phone number must contain exactly 10 digits.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (Hotel.doesUsernameExist(username)) {
                view.showMessage("Username already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            User newUser = new User(name, age, email, phone, password, username, userType);
            boolean success = Hotel.insertUser(newUser);

            if (success) {
                view.showMessage("Sign-up successful! Welcome, " + name, "Success", JOptionPane.INFORMATION_MESSAGE);
                view.showLogInScreen();
            } else {
                view.showMessage("Sign-up failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            view.showMessage("Age must be a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleBookRoom(){
        view.showBookRoomForm();
        view.showFindRoomButton();
    }

    private void handleFindRoom() {
        String nrOfPeople = view.getNrOfPeople();
        String checkInDate = view.getCheckInDate();

        if (nrOfPeople.isEmpty() || checkInDate.isEmpty()) {
            view.showMessage("All fields must be filled out.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {

            int nrPeople = Integer.parseInt(nrOfPeople);
            if (nrPeople <= 0) {
                view.showMessage("Number of people must be greater than zero.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Date checkIn = Date.valueOf(checkInDate);
            Date checkOut = Date.valueOf(view.getCheckOutDate());

            LocalDate currentLocalDate = LocalDate.now();
            Date currentDate = Date.valueOf(currentLocalDate);



            if (checkIn.before(currentDate) && checkOut.before(currentDate)) {
                view.showMessage("Check-in and Check-out date cannot be in the past.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if(checkIn.equals(checkOut)) {
                view.showMessage("Book at least one night!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if(checkIn.after(checkOut)) {
                view.showMessage("Check-out date must be after the Check-in date!.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            User loggedInUser = Hotel.getUserByUsername(view.getLogInUsername());
            List<Room> availableRooms;

            if (loggedInUser.getUserType().equals("Customer")) {
                availableRooms = Customer.getAvailableRooms(nrPeople, checkIn, checkOut);
            } else {
                view.showMessage("You must be logged in as a customer to find rooms.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (availableRooms.isEmpty()) {
                view.showMessage("No available rooms found for the given criteria.", "No Rooms Found", JOptionPane.INFORMATION_MESSAGE);
            } else {
                view.showAvailableRooms(availableRooms);
            }

        } catch (NumberFormatException e) {
            view.showMessage("Please enter a valid number for the number of people.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (DateTimeParseException e) {
            view.showMessage("Please enter a valid date in the format yyyy-MM-dd.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            view.showMessage("An unexpected error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleBookRoomButton() {

        int roomNumber = view.getNumberAvailableRoom();
        String checkInDate = view.getCheckInDate();
        String checkOutDate = view.getCheckOutDate();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        LocalDate checkIn = LocalDate.parse(checkInDate, formatter);
        LocalDate checkOut = LocalDate.parse(checkOutDate, formatter);
        Date dateCheckIn = Date.valueOf(checkIn);
        Date dateCheckOut = Date.valueOf(checkOut);

        User loggedInUser = Hotel.getUserByUsername(view.getLogInUsername());
        String username = loggedInUser.getUserName();

        try{
            Customer.changeRoomStatusToBooked(roomNumber, dateCheckIn, dateCheckOut);
            if(!Customer.doesCustomerExist(username)) {
                boolean success = Customer.insertCustomer(username);
            }
            boolean successBooking = Customer.insertBooking(username, roomNumber, dateCheckIn, dateCheckOut);
            view.showMessage("The room with the number " + roomNumber + " was booked.", "Success", JOptionPane.INFORMATION_MESSAGE);
        }catch(Exception e){
            view.showMessage("The room couldn't be booked." + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    private void handleCancelBookingButton() {
        User loggedInUser = Hotel.getUserByUsername(view.getLogInUsername());
        try{
            if(!Customer.doesCustomerExist(loggedInUser.getUserName())) {
                view.showMessage("The customer was not found. ", "Error", JOptionPane.ERROR_MESSAGE);
                if(!Customer.doesBookingExist(loggedInUser.getUserName())) {
                    view.showMessage("The booking was not found. ", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                return;
            }

            Date checkInDate = Customer.getTheCheckInDate(loggedInUser.getUserName());
            LocalDate currentDate = LocalDate.now();
            if (checkInDate != null && currentDate.isBefore(checkInDate.toLocalDate())){
                double amountToBePayedIfCancelTheBooking = Customer.computeAmountIfCancelBooking(loggedInUser.getUserName());
                boolean successUpdateStatus = Customer.changeRoomStatusToAvailable(loggedInUser.getUserName());
                boolean successDeleteFromBookings = Customer.deleteFromBookings(loggedInUser.getUserName());
                boolean successDeleteCustomer = Customer.deleteCustomerFromDatabase(loggedInUser.getUserName());

                if(successUpdateStatus && successDeleteFromBookings && successDeleteCustomer) {
                    if(amountToBePayedIfCancelTheBooking > 0){
                        view.showMessage("Cancelling one day before the booking. Penalty! Amount to be payed: $" + amountToBePayedIfCancelTheBooking , "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        view.showMessage("The booking was cancelled. Cancellation fee: " + amountToBePayedIfCancelTheBooking, "Success", JOptionPane.INFORMATION_MESSAGE);
                    }

                }
            } else {
                view.showMessage("Booking cannot be canceled after the check-in date. " , "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            view.showMessage("The booking couldn't be cancelled. " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    private void handleReviewButton() {
        view.showReviewPanel();
    }

    private void handleSaveReviewButton() {
        int stars = Integer.parseInt(view.getReviewStars());
        User user = Hotel.getUserByUsername(view.getLogInUsername());

        boolean success = Customer.addReview(user.getUserName(), stars);
        if(success){
            view.showMessage("The rating was added " , "Success", JOptionPane.INFORMATION_MESSAGE);
        } else view.showMessage("A review has already been added." , "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void handleAddRoom() {
        view.showAddRoomForm();
    }

    private void handleSaveRoom() {
        String roomNumber = view.getRoomNumber();
        String roomStatus = view.getRoomStatus();
        String roomCapacity = view.getRoomCapacity();
        String roomPrice = view.getRoomPrice();
        String roomType = view.getRoomType();

        if (roomNumber.isEmpty() || roomStatus.isEmpty() || roomCapacity.isEmpty() || roomPrice.isEmpty() || roomType.isEmpty()) {
            view.showMessage("All fields must be filled out.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int number = Integer.parseInt(roomNumber);
            int capacity = Integer.parseInt(roomCapacity);
            double price = Double.parseDouble(roomPrice);

            Room room = new Room(roomStatus, number, capacity, price, roomType);
            User loggedInUser = Hotel.getUserByUsername(view.getLogInUsername());

            if (loggedInUser instanceof Employee loggedInEmployee) {
                boolean success = loggedInEmployee.addRoom(room);

                if (success) {
                    view.showMessage("Room added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    view.showLogInScreen();
                } else {
                    view.showMessage("Failed to add room. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                view.showMessage("Only employees can add rooms.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            view.showMessage("Capacity and price must be valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleCheckOutCustomerButton() {
        view.showCheckOutForm();
    }

    private void handleCheckOutButton() {
        String number = view.getRoomNumberForCheckOut();
        int room_number = Integer.parseInt(number);

        double totalPrice = Employee.computeTotalAmount(room_number);
        boolean successUpdateStatus = Employee.changeRoomStatusToAvailable(room_number);
        boolean successDeletion = Employee.deleteFromActivitiesAndBookings(room_number);

        if(successUpdateStatus && successDeletion) {
            view.showMessage("The customer has to pay " + totalPrice + "$.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else view.showMessage("The booking couldn't be saved. " , "Error", JOptionPane.ERROR_MESSAGE);

        /// compute the sum just for the booked activities
    }

    private void handleAddFacilityButton() {
        view.showAddFacilityForm();
    }

    private void handleSaveFacilityButton() {
        String facilityName = view.getFacilityName();
        double facilityPrice = Double.parseDouble(view.getFacilityPrice());

        User loggedInUser = Hotel.getUserByUsername(view.getLogInUsername());
        Employee employee = (Employee) loggedInUser;
        boolean success = employee.addFacility(facilityName, facilityPrice);
        if(success){
            view.showMessage("Facility added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            view.showMessage("Failed to add facility. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    private void handleBackButton1() {
        view.customerPanel();
    }

    private void handleBackButton3() {
        view.employeePanel();
    }

    private void handleBookActivityButton() {
        view.showChooseActivityForm();
    }


    private void handleActivityBookingButton() {
        String activity_name = view.getNameFacility();
        User loggedInUser = Hotel.getUserByUsername(view.getLogInUsername());

        boolean bookingFound = Customer.doesBookingExist(loggedInUser.getUserName());
        if(!bookingFound){
            view.showMessage("A booking is required before an activity can be booked " , "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        boolean success = Customer.bookActivity(loggedInUser.getUserName(), activity_name);
        if(success){
            view.showMessage("The activity was booked. " , "Success", JOptionPane.INFORMATION_MESSAGE);
        } else view.showMessage("The activity couldn't be booked. " , "Error", JOptionPane.ERROR_MESSAGE);

    }

}
